import React from "react";

function Follower(){
    return(
        <div>
            <h3>Followers:</h3>
            <p>Siya</p>
        </div>
    );
}

function Following(){
    return(
        <div>
            <h3>Following:</h3>
            <p>Anirudh</p>
        </div>
    );
}
export { Follower, Following };